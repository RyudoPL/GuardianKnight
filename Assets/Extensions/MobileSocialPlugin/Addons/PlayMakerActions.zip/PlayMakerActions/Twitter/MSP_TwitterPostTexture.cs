using UnityEngine;
using System.Collections;


namespace HutongGames.PlayMaker.Actions {
	
	[ActionCategory("Mobile Social Plugin - Twitter")]
	public class MSP_TwitterPostTexture : FsmStateAction {
		
		public FsmString message;
		public FsmTexture texture;
		
		public FsmEvent successEvent;
		public FsmEvent failEvent;
		
		
		public override void OnEnter() {
			
			bool IsInEdditorMode = false;
			
			#if UNITY_EDITOR
			IsInEdditorMode = true;
			#endif
			
			
			if(IsInEdditorMode) {
				Fsm.Event(successEvent);
				Finish();
				return;
			}
			
			
			SPTwitter.Instance.OnPostingCompleteAction += HandleOnPostingCompleteAction;

			
			SPTwitter.instance.Post(message.Value, texture.Value as Texture2D);
			
		}

		void HandleOnPostingCompleteAction (TWResult res){
			
			SPTwitter.Instance.OnPostingCompleteAction -= HandleOnPostingCompleteAction;
			
			if (res.IsSucceeded) {
				Fsm.Event (successEvent);
			} else {
				Fsm.Event(failEvent);
			}
			
			Finish ();
		}


		
	}
}



