using UnityEngine;
using System.Collections;


namespace HutongGames.PlayMaker.Actions {
	
	[ActionCategory("Mobile Social Plugin - Facebook")]
	public class MSP_FB_PostTexture : FsmStateAction {
		
		public FsmString message;
		public FsmTexture texture;
		
		public FsmEvent successEvent;
		public FsmEvent failEvent;
		
		
		public override void OnEnter() {
			
			bool IsInEdditorMode = false;
			
			#if UNITY_EDITOR
			IsInEdditorMode = true;
			#endif
			
			
			if(IsInEdditorMode) {
				Fsm.Event(successEvent);
				Finish();
				return;
			}

			
			SPFacebook.OnPostingCompleteAction += OnPostSuccess;

			
			SPFacebook.instance.PostImage(message.Value, texture.Value as Texture2D);
			
		}




		private void OnPostSuccess(FB_PostResult result){
			if(result.IsSucceeded) {
				Fsm.Event(successEvent); 
			} else {
				Fsm.Event(failEvent);
			}

			Finish();
		
		}
		
	}
}



